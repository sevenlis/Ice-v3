# Ice-v3
order collector for trading agents. put rows into remote MSSQL database. 
get data from remote MSSQL database and put it into local sqlite database.
