package by.ingman.sevenlis.ice_v3.utils;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {}
