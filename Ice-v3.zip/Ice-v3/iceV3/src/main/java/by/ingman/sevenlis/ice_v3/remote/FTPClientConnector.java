package by.ingman.sevenlis.ice_v3.remote;

import org.apache.commons.net.ftp.FTPClient;

import java.io.IOException;

public class FTPClientConnector {
    private static FTPClient ftpClient;

    public static FTPClient getFtpClient() {
        if (ftpClient == null) ftpClient = new FTPClient();
        connectClient();
        return ftpClient;
    }

    private static void connectClient() {
        String server = "ftp.ingman.by";
        int port = 2100;
        String user = "ftpingmanby";
        String pass = "S4IJs3BtNVfw";
        try {
            if (!ftpClient.isConnected()) {
                ftpClient.connect(server,port);
                ftpClient.login(user,pass);
                ftpClient.enterLocalPassiveMode();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void disconnectClient() {
        if (ftpClient.isConnected()) {
            try {
                ftpClient.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
